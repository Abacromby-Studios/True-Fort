// Firebase service worker placeholder
